import requests
import os
import zipfile
import io

github_token = "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"

headers = {
    'Authorization': f'token {github_token}',
    'Accept': 'application/vnd.github.v3+json'
}

crypto_keywords = [
    'cryptography', 
    'Crypto', 
    'ssl', 
    'nacl', 
    'import hashlib', 
    'import fernet', 
    'from cryptography', 
    'from Crypto', 
    'from nacl'
]

def repo_uses_crypto(full_name):
    req_url = f"https://api.github.com/repos/{full_name}/contents/requirements.txt"
    resp = requests.get(req_url, headers=headers)
    if resp.status_code == 200:
        content = requests.get(resp.json()['download_url']).text.lower()
        if any(word.lower() in content for word in crypto_keywords):
            return True

    # Check setup.py
    setup_url = f"https://api.github.com/repos/{full_name}/contents/setup.py"
    resp = requests.get(setup_url, headers=headers)
    if resp.status_code == 200:
        content = requests.get(resp.json()['download_url']).text.lower()
        if any(word.lower() in content for word in crypto_keywords):
            return True

    # Scan Python files at the root
    contents_url = f"https://api.github.com/repos/{full_name}/contents"
    resp = requests.get(contents_url, headers=headers)
    if resp.status_code == 200:
        files = resp.json()
        for file in files:
            if file['type'] == 'file' and file['name'].endswith('.py'):
                content = requests.get(file['download_url']).text.lower()
                if any(word.lower() in content for word in crypto_keywords):
                    return True
    return False

def download_repo(full_name, default_branch):
    zip_url = f"https://api.github.com/repos/{full_name}/zipball/{default_branch}"
    zip_response = requests.get(zip_url, headers=headers)

    if zip_response.status_code == 200:
        repo_dir = full_name.replace("/", "_")
        os.makedirs(repo_dir, exist_ok=True)
        
        with zipfile.ZipFile(io.BytesIO(zip_response.content)) as zip_ref:
            zip_ref.extractall(repo_dir)
        
        print(f"Downloaded and extracted: {full_name}\n")
    else:
        print(f"Failed to download {full_name} (Status: {zip_response.status_code})")

search_query = "language:Python"
search_url = f"https://api.github.com/search/repositories?q={search_query}&sort=stars&order=desc&per_page=10"
response = requests.get(search_url, headers=headers)

repos = response.json().get('items', [])

for repo in repos:
    full_name = repo['full_name'] 
    default_branch = repo['default_branch']
    print(f"🔍 Scanning repo: {full_name}")

    try:
        if repo_uses_crypto(full_name):
            print(f"Crypto libraries detected in {full_name}, downloading...")
            download_repo(full_name, default_branch)
        else:
            print(f"No crypto libraries found in {full_name}, skipping.\n")
    except Exception as e:
        print(f"Error scanning {full_name}: {e}\n")
