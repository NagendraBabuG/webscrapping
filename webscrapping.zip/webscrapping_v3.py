import requests
import os
import zipfile
import io

github_token = "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"

headers = {
    'Authorization': f'token {github_token}',
    'Accept': 'application/vnd.github.v3+json'
}

# Step 1: Search repositories about "cryptography"
search_query = "cryptography language:Python"
search_url = f"https://api.github.com/search/repositories?q={search_query}&sort=stars&order=desc&per_page=5"
response = requests.get(search_url, headers=headers)

repos = response.json().get('items', [])

for repo in repos:
    full_name = repo['full_name']  # Example: 'owner/repo'
    default_branch = repo['default_branch']  # Example: 'main' or 'master'
    print(f"🔍 Downloading repository: {full_name} (branch: {default_branch})")

    # Step 2: Download the zipball
    zip_url = f"https://api.github.com/repos/{full_name}/zipball/{default_branch}"
    zip_response = requests.get(zip_url, headers=headers)

    if zip_response.status_code == 200:
        # Step 3: Extract the zip
        repo_dir_name = full_name.replace("/", "_")
        os.makedirs(repo_dir_name, exist_ok=True)
        
        with zipfile.ZipFile(io.BytesIO(zip_response.content)) as zip_ref:
            zip_ref.extractall(repo_dir_name)
        
        print(f"✅ Downloaded and extracted {full_name} successfully!\n")
    else:
        print(f"❌ Failed to download {full_name} (Status code: {zip_response.status_code})")
