import requests
import os

github_token = "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"

headers = {
    'Authorization': f'token {github_token}',
    'Accept': 'application/vnd.github.v3+json'
}

def download_python_files(full_name, path=""):
    # Build the GitHub API URL
    api_url = f"https://api.github.com/repos/{full_name}/contents/{path}"
    response = requests.get(api_url, headers=headers)

    if response.status_code == 200:
        items = response.json()
        for item in items:
            if item['type'] == 'file' and item['name'].endswith('.py'):
                raw_url = item['download_url']
                print(f"Downloading {item['name']} from {raw_url}")
                
                file_resp = requests.get(raw_url)
                if file_resp.status_code == 200:
                    local_dir = full_name.replace("/", "_")
                    os.makedirs(local_dir, exist_ok=True)
                    local_path = os.path.join(local_dir, item['path'].replace("/", "_"))

                    with open(local_path, 'w', encoding='utf-8') as f:
                        f.write(file_resp.text)
                else:
                    print(f"Failed to download {raw_url}")
            elif item['type'] == 'dir':
                # Recursively scan folders
                download_python_files(full_name, item['path'])
    else:
        print(f"Failed to fetch contents of {path} for {full_name}")

# Step 1: Search repositories about "cryptography"
search_query = "cryptography language:Python"
search_url = f"https://api.github.com/search/repositories?q={search_query}&sort=stars&order=desc&per_page=5"
response = requests.get(search_url, headers=headers)

repos = response.json().get('items', [])

for repo in repos:
    full_name = repo['full_name']  # Example: 'user/repo'
    print(f"🔍 Scanning repository: {full_name}")
    download_python_files(full_name)

