import requests
import os

github_token = "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"

headers = {
    'Authorization': f'token {github_token}',
    'Accept': 'application/vnd.github.v3+json'
}

# Step 1: Search repositories about "cryptography"
search_query = "cryptography language:Python"
search_url = f"https://api.github.com/search/repositories?q={search_query}&sort=stars&order=desc&per_page=5"  
response = requests.get(search_url, headers=headers)
repos = response.json().get('items', [])

for repo in repos:
    full_name = repo['full_name']
    print(f"Scanning repo: {full_name}")
    
    contents_url = f"https://api.github.com/repos/{full_name}/contents"
    contents_resp = requests.get(contents_url, headers=headers)

    if contents_resp.status_code == 200:
        files = contents_resp.json()
        
        for file in files:
            if file['type'] == 'file' and file['name'].endswith('.py'):
                raw_url = file['download_url']
                
                print(f"Downloading {file['name']} from {raw_url}")
                
                code_resp = requests.get(raw_url)
                
                if code_resp.status_code == 200:
                    os.makedirs(full_name.replace("/", "_"), exist_ok=True)
                    file_path = os.path.join(full_name.replace("/", "_"), file['name'])
                    
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(code_resp.text)
                else:
                    print(f"Failed to download {raw_url}")
    else:
        print(f"Failed to fetch contents for {full_name}")

